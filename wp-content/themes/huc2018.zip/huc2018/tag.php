<?php
$templatePage = 'page-big-list.html';
$templatePostSnip = 'item-card.html';

include('_inc-build-6-simple-list.php');
include('_inc-build-4-total-page.php');
?>
