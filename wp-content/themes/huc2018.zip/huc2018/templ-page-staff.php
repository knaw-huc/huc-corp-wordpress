<?php /* Template Name: Page + staff */
$templatePage = 'page-staff.html';

include('_inc-build-1-single-page.php');
include('_inc-build-4-total-page.php');
?>
