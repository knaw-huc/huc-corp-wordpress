var divName = 'grid';
var coorsBackup = [];
var radius = '3';
var perRingAmountArray = [];


// ROW  X
var divWidth = document.getElementById(divName).clientWidth;
var divWidthMid = divWidth/2;

// COLS Y
var divHeight = document.getElementById(divName).clientHeight;
var divHeightMid = divHeight/2;
