if (window.matchMedia("(min-width: 800px)").matches) {
  var elemWidth = document.getElementById("getW").offsetWidth;
  document.getElementById("grid").style.width = elemWidth+"px";
}
