
<?php /* Template Name: Research field */
$templatePage = 'page.html';

include('_inc-build-1-single-page.php');
include('_inc-build-4-total-page.php');
?>
