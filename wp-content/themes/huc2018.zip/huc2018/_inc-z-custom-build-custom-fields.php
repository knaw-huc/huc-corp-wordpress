<?php
  $postCustomMetaKeywords = get_post_meta( get_the_ID(), 'wpcf-extra-keywords', true );
  $postCustomMetaToolName = get_post_meta( get_the_ID(), 'wpcf-tool-name', true );
  $postCustomMetastaffName = get_post_meta( get_the_ID(), 'wpcf-staff-name', true );
  $postCustomMetaFunction = get_post_meta( get_the_ID(), 'wpcf-function', true );
  $postCustomMetaEmail = get_post_meta( get_the_ID(), 'wpcf-email', true );
  $postCustomMetaPhone = get_post_meta( get_the_ID(), 'wpcf-phone', true );
  $postCustomMetaTwitter = get_post_meta( get_the_ID(), 'wpcf-twitter', true );
  $postCustomMetaDepartment = get_post_meta( get_the_ID(), 'wpcf-department', true );
  $postCustomMetaInstitute = get_post_meta( get_the_ID(), 'wpcf-institute', true );

?>
